# Bölüm 17 — Rubrik eşlemesi ve teslim

Mevcut P1 rubriği ve puanları korunur. Aşağıdaki eşleme hangi ortak boyutların
yerel ölçütte yer aldığını gösterir. Çok boyutlu yerel puanlar bölünüp yeniden
dağıtılmaz; iki rubrik aynı teslimi iki kez puanlamak için kullanılmaz. Dönem
projesinde hangi rubriğin kullanılacağı önceden bildirilir.

## Yerel P1 → ortak çatı

| Yerel ölçüt | Mevcut puan | İlişkili ortak boyutlar |
|---|---:|---|
| kaynak/puanlama | 20 | K1 |
| hesap ve eksikler | 25 | K1,K3 |
| belirsizlik ve madde kararı | 20 | K2,K4 |
| uyarlama planı | 25 | K2,K5 |
| yeniden üretim | 10 | K3 |

## Ortak dönem projesi çerçevesi

| Kod | Ölçüt | Puan |
|---|---|---:|
| K1 | Kaynak, veri sözlüğü ve analiz birimi | 15 |
| K2 | Araştırma hedefi ve yöntem gerekçesi | 20 |
| K3 | Hesabın doğruluğu ve yeniden üretilebilirlik | 20 |
| K4 | Belirsizlik, tanılar ve duyarlılık | 20 |
| K5 | Yorum ve kapsam sınırları | 15 |
| K6 | Açık ve düzenli raporlama | 10 |

## Öğrenci kararı ve kısa savunma

Ham veya standart madde toplamı puanını seçin; katsayı değişimini puan tanımı ve ortak kayıtlarla açıklayın.

Kararı, gerekçeyi, tek değişikliği, önce/sonra kanıtını, belirsizliği ve kapsam
sınırını kaydedin. Ç1 yanıtını ekleyin. Savunmada 3–5 dakika içinde hedefinizi,
hangi sonucun değiştiğini ve neyin kanıtlanmadığını açıklayın.

`ogrenci-karari.json` dosyası çıktı ZIP’ine eklenir. Varsayılan boş alanlar
tamamlanmış sayılmaz. Alanların dolu olması veya sayısal kontrollerin geçmesi
akademik yeterlik için otomatik onay değildir.
