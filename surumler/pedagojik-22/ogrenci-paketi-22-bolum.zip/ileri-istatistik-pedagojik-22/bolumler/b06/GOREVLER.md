# Bölüm 6 — görevler

Güncel kitap bölümünün etkinlik ve alıştırmalarıdır. Önce kendi çözümünüzü
üretin; ardından çözümleri kontrol edin. Kitap sayfa numaraları PDF sürümüne
göre değişebilir.

## D1–D3: Sayıdan Önce

1.  Beş puanlık fark ve on puanlık standart sapma hangi iki farklı girdidir? d=.5 onların gerekçesini ortadan kaldırır mı?

2.  “n=64” ifadesi bu tasarımda toplam kişi mi, grup başına kişi mi belirtmelidir? Eşli desende n ne olur?

3.  Anlamlı sonuç elde edene kadar kişi eklemek burada hesaplanan gücün planıyla aynı mıdır?

# Rehberli ve Bağımsız Etkinlikler

## G1–G4: Rehberli Çözüm

1.  Ana planın d, serbestlik derecesi ve merkezi olmama parametresini 64 kişi/grup için bulun. 63/64 güçleri neden birlikte verilir?

2.  Güç hedefi .90 veya alfa .01 olursa minimum sayıları ve toplamları karşılaştırın.

3.  64 tam kayıt hedefinde yüzde 15 kayıp için 76 sonucunu hesaplayın. Binom modelindeki .422777 neyin olasılığıdır?

4.  Arşiv s’siyle .5 saatlik plan farkının $d_z$ ve tam çift sayısını bulun. Bu neden gerçek klinik pilot kararı değildir?

## B1–B3: Bağımsız Çözüm

1.  40 kişi/grupta .50 etkisinin gücünü ve .80 güç veren etkiyi yorumlayın. Bunu önemli farkla eşitlemek uygun mudur?

2.  2:1 dağılımda gereken kişi sayılarını; üçlü Bonferroni planında tekil güç ile tüm testlerin gücünü ayırın.

3.  Korelasyon için yaklaşık 85, eşli $d_z=.5$ için 34 sonuçlarının birimlerini açıklayın. `power.t.test` çağrısına .3 yazmak niçin korelasyon hesabı değildir?

## H1: Hatalı Planı Onarma

> “d=.5 her alanda önemli etkidir. n=64 toplam kişi yeter. Pilotun büyük etkisini gerçek kabul ettik. Yüzde 15 kayıp için 76 kişi/grup alınca 64’er tam kayıt garanti. Gücümüz .8 olduğundan üç testin hepsi yüzde 80 olasılıkla anlamlı. Sonuç anlamsızsa kişi ekleyip testi tekrarlarız.”

Altı iddiayı hedef, birim, belirsizlik ve durdurma planıyla düzeltin.

## P1: Denetlenebilir Örneklem Gerekçesi

Yeni bir çalışma için birincil karşılaştırma, önemli/beklenen etki ve dayanakları, yayılım/ilişki senaryoları, yön/alfa, hedef güç veya hassasiyet, grup oranı, analiz ve kayıt sayıları, kayıp modeli, çoklu aile ve durdurma kuralını yazın. Kaynak sınırı varsa uygun duyarlılık eğrisi ekleyin. Rubrik: hedef/tasarım 25, etki gerekçesi 25, hesap/birim 25, kayıp/çokluk 15, yeniden üretim 10 puan.

Yanıtlar Ek F, Bölüm 5’tedir (s. kitaptaki ilgili sayfa).

# Alıştırmalar

Bu alıştırmalar güç, etki büyüklüğü, örneklem büyüklüğü ve araştırma planlama kararlarını pekiştirmek için üç düzeyde düzenlenmiştir.

## Kolay Düzey

1.  İstatistiksel güç kavramını tanımlayınız.

2.  Tip I hata ile Tip II hata arasındaki farkı yazınız.

3.  Etki büyüklüğü neden yalnızca $p$ değerinden daha bilgilendiricidir?

4.  Örneklem büyüklüğü arttığında standart hata genel olarak nasıl değişir?

5.  Güç analizinde alfa düzeyi, güç ve etki büyüklüğünün rolünü kısaca belirtiniz.

## Orta Düzey

1.  Aynı etki büyüklüğü için güç hedefi .80’den .90’a çıkarılırsa örneklem büyüklüğü nasıl etkilenir?

2.  Küçük etki büyüklüğünü yakalamak için neden daha büyük örnekleme ihtiyaç duyulur?

3.  Yetersiz güçlü bir çalışmada anlamsız sonuç nasıl yorumlanmalıdır?

4.  Pilot çalışma sonuçlarının güç analizinde kullanımını tartışınız.

5.  Klinik/pratik önem ile istatistiksel anlamlılık arasındaki farkı açıklayınız.

## İleri Düzey

1.  Güç analizinin araştırma etiğiyle ilişkisini örnekle açıklayınız.

2.  Çoklu karşılaştırmaların güç ve hata oranları üzerindeki etkisini tartışınız.

3.  Korelasyon ve regresyon çalışmalarında güç analizinin farklılaşabileceği noktaları belirtiniz.

4.  Gerçekçi olmayan büyük etki varsayımının örneklem planlamasını nasıl yanıltabileceğini açıklayınız.

5.  Bir tez çalışması için güç analizi raporunda bulunması gereken unsurları yazınız.


## Revizyon 9: eşdeğerlik gücü ve hassasiyet

## T1–T3: Güç ve Hassasiyet Hedeflerini Eşleştirme

1.  $\Delta=5$, $\sigma=10$ eşdeğerlik planında gerçek fark 0 için 70, 2.5 için 199 kişi/grup bulunmasını yorumlayın. Ana fark testinin 64 kişi/grup sonucu neden doğrudan taşınamaz? Gerçek fark tam 5 ise .80 eşdeğerlik gücü hedeflemek ne anlama gelir?

2.  Yarı genişlik en fazla 2 puan hedefinde yerine koymalı n=194 ile olasılık hedefli n=211’i ayırın. .906617 olasılığı %95 aralığın kapsama düzeyi veya test gücü müdür?

3.  Sayısal integralin 100 000 tekrarla denetlenmesi yeni katılımcı sayısı veya gerçek pilot belirsizliği üretir mi? Güç/genişlik/tutulma olasılıklarını çarpmak neden ayrıca gerekçe ister?

## Çekirdek öğrenme rotası

1. Önemli farkı, beklenen etkiyi ve planlama varsayımlarını ayırır.
2. Grup başına, toplam ve analiz edilebilir kişi sayılarını doğru belirtir.
3. Güç, hassasiyet ve kayıt kaybı senaryolarını yorumlar.

**İleri rota:** Merkezi olmayan t hesabı Bölüm 5 sonrasında; TOST ve gerçekleşen aralık genişliği ileri planlama rotasıdır.

**Ç1:** Planlanan gücün .80 olması eldeki çalışmanın mutlaka anlamlı çıkacağını garanti eder mi?

**Karar görevi:** Beklenen etki veya tutulma varsayımından yalnız birini değiştirin; gereken kişi sayısını ve değişmeyen bilimsel hedefi belirtin.

[Rubrik ve teslim rehberi](RUBRIK.md).
