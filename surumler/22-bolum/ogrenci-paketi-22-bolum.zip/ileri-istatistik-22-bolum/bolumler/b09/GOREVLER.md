# Bölüm 9 — görevler

Güncel kitap bölümünün etkinlik ve alıştırmalarıdır. Önce kendi çözümünüzü
üretin; ardından çözümleri kontrol edin. Kitap sayfa numaraları PDF sürümüne
göre değişebilir.

## D1–D3: Analizden Önce

1.  Neden 700 değil 687 kişi analiz edilir? Bu kararın varsayımı nedir?

2.  Eğitim kodlarını 0–5 arası sürekli bir değişken gibi kullanmak neden sorunludur?

3.  ACT, SATV ve SATQ’yu birlikte analiz etmenin kuramsal gerekçesi ne olabilir? Hangi araştırma sorusu için üç ayrı analiz daha uygundur?

Yanıtlar Ek F, Bölüm 9’dadır (s. kitaptaki ilgili sayfa).

# Rehberli ve Bağımsız Etkinlikler

## G1–G4: Rehberli Çözüm

1.  Cinsiyet karşılaştırmasında $D=.426$’dan $T^2$’yi ve F’yi hesaplayın.

2.  Özdeğerler .0356, .0078, .0014 iken Wilks, Pillai, Hotelling–Lawley ve Roy değerlerini hesaplayın.

3.  $1-\Lambda^{1/s}$ ve $V/s$ ile çok değişkenli etki büyüklüğünü bulun; ACT’nin tek değişkenli $\eta^2$’siyle karşılaştırın.

4.  Standartlaştırılmış ayırma katsayısı SATV için negatifken tek değişkenli SATV farkı neden pozitiftir?

## B1–B3: Bağımsız Çözüm

1.  Box M sonucu ve grup standart sapmaları ışığında hangi istatistiği raporlarsınız? Gerekçelendirin.

2.  Altı uç değerin duyarlılık analizini yorumlayın. Bu kayıtları silmek için hangi ek bilgi gerekir?

3.  İki faktörlü sonuçları, cinsiyetin tek başına iki grup analiziyle karşılaştırın. Tip II ile Tip III ne zaman farklılaşır?

## H1: Hatalı Raporu Onarma

> “MANOVA anlamlı olduğu için üç puanda da eğitim farkı vardır. Roy’un $p<.001$ değeri en güçlü kanıttır. Box M anlamlı olduğundan MANOVA yapılamaz. Sonra üç ayrı ANOVA’yı .05 düzeyinde yaptık. Cinsiyet SATV’de farksız olduğu için SATV ayırma fonksiyonunda önemsizdir.”

Beş iddiayı düzeltin.

## P1: MANOVA Planı

Bir eğitim müdahalesinin okuma, yazma ve matematik başarısına etkisini sınayacak bir çalışma için analiz planı yazın: bağımlı değişken seçiminin gerekçesi, beklenen korelasyonlar, istatistik seçimi, varsayım denetimleri (uç değer, Box M), izleme stratejisi (ayırma fonksiyonu mu, düzeltilmiş ANOVA mı), etki büyüklüğü ve örneklem gerekçesi. Rubrik: kuram 20, analiz planı 30, varsayımlar 20, izleme 20, raporlama 10 puan.

# Alıştırmalar

## Kolay Düzey

1.  MANOVA’nın sıfır hipotezi nedir?

2.  SSCP matrisinin köşegen ve köşegen dışı öğeleri neyi gösterir?

3.  Dört çok değişkenli istatistikten hangisi varsayım ihlallerine en dayanıklıdır?

4.  Hotelling $T^2$ hangi durumda kullanılır?

5.  Box M testi neyi sınar?

## Orta Düzey

1.  İki bağımlı değişken arasında $r=.95$ vardır. MANOVA yerine ne önerirsiniz?

2.  Wilks $\Lambda=.80$, $s=2$ bulunmuştur. Çok değişkenli etki büyüklüğünü hesaplayın.

3.  MANOVA anlamsız, fakat tek değişkenli ANOVA’lardan biri anlamlıdır. Nasıl yorumlarsınız?

4.  Grup büyüklükleri 20, 20 ve 120 olan bir desende Box M $p<.001$’dir. Hangi istatistiği seçersiniz, neden?

5.  Ayırma fonksiyonu katsayıları ile yapı katsayıları arasındaki fark nedir?

## İleri Düzey

1.  İki grup için tek değişkenli iki t-testi anlamsızken Hotelling $T^2$ nasıl anlamlı olabilir? Bir örnek verin.

2.  Tekrarlı ölçümler ANOVA’sındaki çok değişkenli yaklaşım ile MANOVA arasındaki ilişkiyi açıklayın.

3.  Bağımlı değişken sayısı arttıkça MANOVA’nın gücü nasıl değişir? Hangi koşulda düşer?

4.  Dengesiz iki faktörlü MANOVA’da Tip II ve Tip III sonuçları farklıysa ne raporlarsınız?

5.  Güçlü bir MANOVA raporunda bulunması gereken en az beş unsuru yazın.
