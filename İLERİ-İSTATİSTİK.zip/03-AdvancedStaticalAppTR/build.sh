#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

mode="auto"
for arg in "$@"; do
  case "$arg" in
    --bibtex) mode="force" ;;
    --no-bibtex) mode="skip" ;;
    *)
      echo "Kullanım: bash build.sh [--bibtex|--no-bibtex]" >&2
      exit 1
      ;;
  esac
done

run_latex() {
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
}

run_index() {
  if [[ ! -f main.idx ]]; then
    return 0
  fi

  if command -v texindy >/dev/null 2>&1; then
    texindy -L turkish -C utf8 -o main.ind main.idx
  elif command -v xindy >/dev/null 2>&1; then
    xindy -L turkish -C utf8 -M texindy -o main.ind main.idx
  elif command -v makeindex >/dev/null 2>&1; then
    echo "Uyarı: texindy/xindy bulunamadı; dizin makeindex ile ASCII sıralı üretilecek." >&2
    makeindex main.idx
  else
    echo "Uyarı: texindy/xindy/makeindex bulunamadı, dizin adımı atlandı." >&2
  fi
}

needs_bibtex() {
  case "$mode" in
    force) return 0 ;;
    skip) return 1 ;;
  esac
  grep -Eq '\\bibliography\{|\\addbibresource\{' main.tex
}

python3 assets/scripts/restore_figures.py --check

run_latex
run_index
run_latex

if needs_bibtex; then
  if command -v bibtex >/dev/null 2>&1; then
    if [[ -f main.aux ]] && grep -q "\citation{" main.aux; then
      bibtex main
      run_latex
      run_index
      run_latex
    else
      echo "Bilgi: BibTeX gerektiren aktif bir atıf bulunmadı, bibtex adımı atlandı."
    fi
  else
    echo "Uyarı: bibtex bulunamadı, kaynakça adımı atlandı." >&2
  fi
fi