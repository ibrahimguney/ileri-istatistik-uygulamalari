#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"

interval="2"
build_args=()

for arg in "$@"; do
  case "$arg" in
    --bibtex|--no-bibtex)
      build_args+=("$arg")
      ;;
    *)
      if [[ "$arg" =~ ^[0-9]+$ ]]; then
        interval="$arg"
      else
        echo "Kullanım: bash watch.sh [saniye] [--bibtex|--no-bibtex]" >&2
        exit 1
      fi
      ;;
  esac
done

compute_state() {
  find . -type f \( -name "*.tex" -o -name "*.bib" -o -name "*.sty" \)     ! -name "main.aux" ! -name "main.log" ! -name "main.out" ! -name "main.toc"     ! -name "main.bbl" ! -name "main.blg" ! -name "main.fls" ! -name "main.fdb_latexmk"     ! -name "main.synctex" ! -name "main.synctex.gz"     -print0 | sort -z | xargs -0 stat -c "%n %Y" 2>/dev/null | sha256sum | cut -d" " -f1
}

echo "İzleme başladı. Çıkmak için Ctrl+C kullanın."
echo "Her değişiklikte: clean.sh + build.sh çalıştırılır."

last_state="$(compute_state)"
bash rebuild.sh "${build_args[@]}" || true

while true; do
  sleep "$interval"
  current_state="$(compute_state)"
  if [[ "$current_state" != "$last_state" ]]; then
    echo "Değişiklik algılandı: $(date '+%Y-%m-%d %H:%M:%S')"
    bash rebuild.sh "${build_args[@]}" || true
    last_state="$current_state"
  fi
done