# Bölüm 15 — Doğrulayıcı faktör analizi

## Veri ve doğrulama sınırı

Bölüm 13'ün `../b13-guvenirlik/kaynak/bfi-ilk100-AC.csv` dosyası değiştirilmeden
kullanılır. Kaynak, Rdatasets psych/bfi aktarımının ilk 100 satırından on A/C
maddesidir. A1/C4/C5 `7-x` ile çevrilir; eksik satırlar 63/66/90 çıkarılır: n=97.
Bölüm 14'teki kişiler aynıdır: **bağımsız DFA doğrulaması değildir**. Özgün
2800 kaydın tamamı veya Türkçe uyarlama çalışması olarak gösterilemez.
Kaynak CSV'nin web üzerinden aktarımının sınırları Bölüm 13 README'sindedir;
uzak dosya/psych paketiyle otomatik hücre doğrulaması yapılmış değildir.

Kaynak:
https://raw.githubusercontent.com/vincentarelbundock/Rdatasets/master/csv/psych/bfi.csv
Veri tanımı: https://www.personality-project.org/r/html/bfi.html
Tek son LF ile normalize SHA-256:
`8726fd25dbfc685be2d3d726e5511bbb31ba9c7b367b6864eb06e0d8669e6557`.
Ham bayt hash'i ayrıca kaydedilir; kaynak dosyası değişmez. Hash kaynak
hücrelerinin bağımsız doğruluğunu değil, arşiv kopyasının korunmasını denetler.

## Çalıştırma ve dosyalar

Kitap kökünde:

```sh
python uygulamalar/b15-dogrulayici-faktor/analiz.py
```

Python betiği kendi konumuna göre yolları kurar; başka dizinden de çalıştırılabilir.
Mevcut numpy/pandas/scipy/matplotlib yeterlidir; yeni paket kurulmaz. Sürümler JSON'dadır.

- `puanlanmis.csv`: 97 tam kaydın anahtarlanmış yanıtları ve kaynak etiketleri.
- `standartlastirilmis.csv`: aynı on maddenin ddof=1 z-puanları; kaynak sırası korunur.
- `sonuclar/orneklem_kovaryans.csv`: ddof=1 S, Pearson matrisine eşit.
- `sonuclar/ozet.json`: tanımlar, modeller, indeksler, yükler, aralıklar ve denetimler.
- `sonuclar/*_model.csv`, `*_artik.csv`, `*_yukler.csv`: model kovaryansları,
  örneklem varyanslarıyla standartlaştırılmış artıklar ve madde sonuçları.
- Kitap `assets_figures/b15-yuk-araliklari.pdf`: M1 standart yük aralıkları.
- `analiz.R`: kurulu lavaan ile karşılaştırmaya hazır betik; paket kurmaz.
- `amos-kontrol-listesi.md`: AMOS'ta yapılacak kurulum ve denetimler.

R betiğinde çalışma dizini kitap kökü olmalıdır. Python'un ürettiği dosya önceden
hazır olmalıdır. **R/lavaan ve AMOS bu ortamda çalıştırılmadı.** Tabloların
AMOS'tan geldiği veya lavaan ile sayısal olarak doğrulandığı ileri sürülmez.

## Modeller ve hedef fonksiyon

M0: ilişkisiz iki faktör, 20 serbest parametre, sd=35.
M1: ilişkili iki faktör, 21 parametre, sd=34.
M2: M1 + A2'nin C çapraz yükü, 22 parametre, sd=33.
On artık varyansı serbest, artık kovaryansları sıfır; gizil varyanslar 1.
M0, CFI'nin bağımsız göstergeli başlangıç modeliyle aynı değildir (başlangıç sd=45).

Yaklaşık sürekli maddeler üzerinde normal-kuram kovaryans ML öğretim hesabıdır:
`F = logdet(Sigma) + tr(S @ inv(Sigma)) - logdet(S) - p`.
S, örneklem standart sapmasıyla standartlaştırılmış maddelerin ddof=1 kovaryansıdır.
Wishart çarpanı `T=(n-1)*F`; ortalama yapısı yok. WLSMV, MLR, FIML, polikorik
korelasyon, ölçek eşikleri veya çok gruplu model uygulanmaz.

RMSEA, lavaan'ın n paydalı tanımıyla `sqrt(max((T-df)/(n*df),0))`;
%90 aralık merkezi olmayan ki-kare CDF'sinin .95/.05 için terslenmesidir.
SRMR örneklem varyansıyla standartlaştırılmış kovaryans artıklarının köşegen dahil
55 alt üçgen hücresinin kare ortalamasının kareköküdür. Köşegen dışı 45 çiftlik
RMSR ayrıca verilir. CFI/TLI normal kuramlıdır, sağlam düzeltme içermez.
`AIC_star=T+2*q`, `BIC_star=T+q*log(n)` ortak olabilirlik sabiti çıkarılmış
karşılaştırma ölçüleridir; AMOS/lavaan'ın tam AIC/BIC sayılarıyla eşit değildir.

Artık varyansları log-parametre, faktör ilişkisi tanh-parametre ile temsil edilir.
Sayısal arama sınırları yükler [-3,3], log varyanslar [-12,3], korelasyonun
dönüştürülmüş parametresi [-4,4]'tür. Sonuç herhangi bir sınıra yaklaşırsa betik
durur; pozitif varyans dönüşümünün uygunsuz/Heywood çözümü gizlemediği varsayılmaz.
Bu veride sınır sorunu yoktur. Genel SEM tahminleyicisi olarak kullanmayın.

## Belirsizlik ve denetimler

Dört başlangıç L-BFGS-B ile aynı amaç değerine gelir; BFGS ayrıca denetlenir.
Küçük gradyan, kovaryans eşitliği ve sınırdan uzaklık kontrol edilir. Analitik
amaç/kovaryans türevleri merkezi sonlu farklarla karşılaştırılır. F, genelleştirilmiş
özdeğerlerle bağımsız biçimde yeniden hesaplanır. Yerel kovaryans-Jacobian rankı
parametre sayısına eşittir. Bunlar küresel tek çözüm veya model doğruluğu ispatı değil.

Beklenen bilgi `(n-1)/2 * tr(Sigma^-1 D_a Sigma^-1 D_b)` formülündendir;
model kovaryansındaki sayısal Hessian ile ayrıca doğrulanır. Standart yüklerin
SE'leri delta yöntemidir; %95 Wald aralıkları eşzamanlı değil tekildir ve sağlam
değildir. Phi aralığı tanh-parametre ölçeğinden geri dönüştürülür. BFGS durumu
JSON'a kaydedilir; `success` tek başına değil gradyan/kovaryans denetimleriyle okunur.

M1: T=45.138110, sd=34, CFI=.935763, TLI=.914981, RMSEA=.058114
(%90 GA [0,.099618]), SRMR=.078238, phi=.339936.
M0−M1 nominal p=.013405; M1−M2 nominal p=.005799. İkinci alternatif AFA'dan
sonra seçildiğinden p değeri model seçimine göre düzeltilmiş kanıt değildir.
Basit-model AVE/CR yalnız M1'de hesaplanır. CR model-standartlaştırılmış madde
toplamı için omega türündedir; ham alfa veya on maddelik tek toplam değildir.
CR/AVE aralıkları, otomatik MI taraması, bootstrap, sağlam/ordinal duyarlılık,
ölçüm değişmezliği ve bağımsız doğrulama yapılmamıştır.

## Yöntem kaynakları

Erişim 6 Eylül 2026; veri arşivi geçmişi 5 Eylül 2026.
- Rosseel (2012): https://doi.org/10.18637/jss.v048.i02
- https://lavaan.ugent.be/tutorial/est.html
- https://lavaan.ugent.be/tutorial/cfa.html
- https://lavaan.ugent.be/tutorial/cat.html
- https://lavaan.ugent.be/tutorial/cov.html
- https://lavaan.ugent.be/tutorial/modindices.html
- https://raw.githubusercontent.com/yrosseel/lavaan/master/R/lav_fit_rmsea.R
- https://raw.githubusercontent.com/yrosseel/lavaan/master/R/lav_fit_srmr.R
- https://search.r-project.org/CRAN/refmans/semTools/html/AVE.html
- https://search.r-project.org/CRAN/refmans/semTools/html/compRelSEM.html