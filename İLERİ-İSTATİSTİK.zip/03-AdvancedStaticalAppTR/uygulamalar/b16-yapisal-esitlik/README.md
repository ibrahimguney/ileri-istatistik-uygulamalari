# Bölüm 16 — Ölçüm modelinden yapısal modele

## Kaynak ve önceki AMOS anlatımı
Revelle, W. `psych/bfi` arşivinin Bölüm 13'te korunan ilk 100 A/C kaydı.
Tanım: https://www.personality-project.org/r/html/bfi.html
Aktarım: https://raw.githubusercontent.com/vincentarelbundock/Rdatasets/master/csv/psych/bfi.csv
Bölüm 13 README'sindeki aktarım/kullanım notları geçerlidir. Bu dosya Türkçe
uyarlama, John BFI ölçeği veya 2800 kişinin tüm verisi değildir. A1/C4/C5 ters
anahtarlanır (7-x); 63/66/90 kaynak sıraları eksik nedeniyle yalnız bu tam-kayıt
analizinden çıkarılır; ham arşiv korunur. n=97 ve 10 madde kullanılır.
Aynı kayıtlar Bölüm 14–15'te kullanılmıştır; bağımsız doğrulama yapılmış değildir.
Yerel hash kontrolü, uzak R kaynağıyla hücre karşılaştırması değildir.
LF-normalize SHA-256:
`8726fd25dbfc685be2d3d726e5511bbb31ba9c7b367b6864eb06e0d8669e6557`.

Önceki bölüm metninde HolzingerSwineford1939 için n=301, chi²=85.022, sd=24
ve bazı yollar “gerçek AMOS çıktıları” olarak sunuluyordu. Bu çalışma kopyasında
o AMOS raporu, AMW veya ilgili ham veri bulunmadığından kaynak çıktıyı doğrulama
olanağı yoktu. Bu sayılar yeni veriyle yeniden üretilmiş gibi gösterilmedi;
ana uygulama yerel BFI arşiviyle değiştirildi. Bu değişiklik önceki sayıların
mutlaka yanlış olduğu iddiası değil, doğrulanabilirlik tercihidir.

## Çalıştırma
Kitap kökünden:
```sh
python uygulamalar/b16-yapisal-esitlik/analiz.py
Rscript uygulamalar/b16-yapisal-esitlik/analiz.R
```
Python NumPy/SciPy/pandas/matplotlib kullanır. Bölüm 15 `analiz.py` dosyası,
CFA eşdeğerliğinin kontrolü ve RMSEA aralığı için modül olarak yüklenir; onun
main fonksiyonu çalıştırılmaz, dosyaları değiştirilmez. Genel amaçlı SEM
kütüphanesi değildir. R betiği kurulu lavaan gerektirir, paket kurmaz; önce
Python'un standartlaştırılmış verisi ve sonuçları oluşturulmalıdır.
**Python çalıştırıldı; R/lavaan ve AMOS çalıştırılmadı.**

## Modeller
Bütün göstergeler ddof=1 ile standartlaştırılır. Ortalama yapısı yoktur.
A→A1 ve C→C1 marker yükleri 1; diğer sekiz yük ve on gösterge hata varyansı serbest.
Çapraz yük/hata kovaryansı yoktur. A ve C, kaynak A/C maddelerinin kuramsal
faktör etiketleridir; onaylanmış kişilik teşhisi veya nedensel sıra değildir.

- İleri: C=gamma*A+zeta_C. Var(A)=u, Var(zeta_C)=psi; Cov(A,zeta_C)=0.
  21 parametre, sd=55-21=34.
- Ters: A=delta*C+zeta_A; aynı ölçüm modeli, 21 parametre ve sd=34.
- Sıfır yol: gamma=0; 20 parametre ve sd=35. Bu model on göstergenin
  bağımsızlık başlangıç modeli değildir; her faktör içinde ortaklık sürer.

İleri modelde latent Phi=[[u,gamma*u],[gamma*u,gamma²*u+psi]] ve
Sigma=Lambda*Phi*Lambda'+Theta. Standart yol gamma*sqrt(u/Var(C));
R²_C=gamma²*u/Var(C). İki pozitif latent varyanslı serbest faktör arasındaki
kovaryansın ileri/ters regresyon parametreleştirmeleri aynı Sigma'yı verir.
Bu yüzden ileri/ters modeller arasında nedensel yön seçen uyum testi yoktur.
İki model birbirinden farklı kısıtlar taşımadığından fark chi² testinde sd=0
ile p üretilmez. Gerçek veri uygulamasında aracı değişken veya dolaylı yol yoktur.

## Tahmin ve belirsizlik sözleşmesi
Normal-kuram ML: F=logdet(Sigma)+tr(S*Sigma^-1)-logdet(S)-10.
Wishart istatistiği (n-1)F; S ddof=1; sağlam/ordinal tahminci kullanılmaz.
Maddeler 1–6 kategorili olduğundan sürekli-normal yaklaşım bir öğretim
sınırlamasıdır. WLSMV, polikorik matris, FIML, bootstrap veya değişmezlik yoktur.

Yük sınırları [-10,10], log varyans sınırları [-12,4], gamma sınırı [-10,10].
Varyanslar exp dönüşümündedir. Sınır yakınlığı, rank eksikliği, büyük gradyan
veya yakınsama sorunu varsa betik durur; pozitif dönüşümün Heywood sorununu
çözdüğü iddia edilmez. Üç başlangıç ve iki optimizasyon algoritması kullanılır.
Yerel Jacobian rankı 21/20, küresel tanımlanabilirlik ispatı değildir.

Beklenen bilgi I_ab=(n-1)/2 tr(Sigma^-1 D_a Sigma^-1 D_b).
Tersi parametre kovaryansı; standart yol/R² için delta yöntemi kullanılır.
Ham gamma için normal-kuram Wald %95 aralığı ve p raporlanır. Standart yol
aralığı ayrıca atanh(beta) ölçeğinde delta yöntemiyle hesaplanıp geri çevrilir;
standart yol bu iki-faktörlü örnekte korelasyona eşittir. R²'nin [0,1] aralığında
kalan aralığı bu beta aralığının karesi üzerinden elde edilir; beta aralığı
sıfırı içeriyorsa alt uç 0 alınır. Bu aralıklar tekil, yaklaşık ve sağlam değildir.
CSV/JSON'daki simetrik Wald varyans/R² aralıkları negatif uç verebilir; negatif
varyans tahmini gibi okunmaz. Kitap fiziksel aralıkları yorumlarken dönüşümlü
aralık türünü açıklar; veriyle uyumsuz uçlar sessizce kesilmez.

Normal ML sıfır-yol karşılaştırması LR testidir. Ham gamma Wald p=.064892,
LR p=.013405; ikisi aynı sıfır kısıtını farklı asimptotik yaklaşımlarla değerlendirir.
Wald dönüşüme değişmez değildir ve küçük örneklem/weak marker belirsizliği
önemlidir. En küçük p seçilmez; iki hesap açık raporlanır. Profil olabilirlik
veya bootstrap ile ek güven aralığı bu pakette hesaplanmaz.

RMSEA=sqrt(max((T-df)/(n*df),0)); %90 aralık merkezi olmayan ki-kare ile.
SRMR, örneklem varyanslarıyla standartlaştırılmış artıkların köşegen dahil
55 alt üçgen hücresinin RMS'idir. CFI/TLI başlangıç sd=45.
AIC_star=T+2q ve BIC_star=T+q log(n) ortak olabilirlik sabiti çıkarılmış
karşılaştırma sayılarıdır; yazılımların tam AIC/BIC sütunları değildir.

## Sonuçlar ve dosyalar
- `puanlanmis.csv`, `standartlastirilmis.csv`: 97 kaydın dönüşümleri ve kaynak anahtarları.
- `sonuclar/ozet.json`: kaynak/sürüm, üç model, belirsizlik, LR ve denetimler.
- `orneklem_kovaryans.csv`, `*_kovaryans.csv`, `*_artik.csv`: girdi, ima edilen
  kovaryanslar ve standartlaştırılmış artıklar.
- `*_yukler.csv`, `yapisal_parametreler.csv`, `uyum.csv`: hesap tabloları.
- `assets_figures/b16-yukler-artiklar.pdf`: yükler ve artık ısı haritası.
- `analiz.R`: lavaan karşılaştırması; `amos-kontrol-listesi.md`: kurulum/yorum.

Kontrol noktaları: n=97, gamma=.739950, Var(A)=.092572, psi_C=.387938,
Var(C)=.438624, beta=.339936, R²_C=.115556. Ters gamma=.156168.
İleri/ters chi²=45.138110, sd=34; CFI=.935763, TLI=.914981,
RMSEA=.058114 (%90 aralık [0,.099618]), SRMR=.078238.
Sıfır-yol chi²=51.252957, sd=35; Δchi²=6.114847, p=.013405.

Türevler merkezi sonlu farkla, bilgi matrisi model-kovaryansındaki sayısal
Hessian ile, hedef fonksiyon genelleştirilmiş özdeğerlerle denetlenir.
Bölüm 15'in birim-varyans CFA çözümünden marker ölçeğine geçiş ve bağımsız
yapısal tahminler karşılaştırılır. İleri, ters ve CFA kovaryansları eşittir.
Bunlar model doğruluğu, bağımsız doğrulama veya nedensellik kanıtı değildir.

## Kurgu aracılık
Bölümün üç-yapılı örneği yalnız cebir öğretimidir: a=.48, b=.41, c'=.19,
ab=.1968, toplam=.3868. Bu değerler BFI verisinden hesaplanmaz; kurgu için
p, güven aralığı veya çalıştırılmamış bootstrap sonucu eklenmez.

## Yöntem belgeleri (6 Eylül 2026)
https://lavaan.ugent.be/tutorial/sem.html
https://lavaan.ugent.be/tutorial/est.html
https://lavaan.ugent.be/tutorial/mediation.html
https://lavaan.ugent.be/tutorial/cat.html