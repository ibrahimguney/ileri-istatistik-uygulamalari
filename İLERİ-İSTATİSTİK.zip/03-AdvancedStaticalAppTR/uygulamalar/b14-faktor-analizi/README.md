# Bölüm 14 — Gerçek veride açıklayıcı faktör analizi

## Kaynak ve sınır

Bu paket Bölüm 13'teki `../b13-guvenirlik/kaynak/bfi-ilk100-AC.csv` dosyasını
**değiştirmeden** kullanır. Yeni yanıt veya yeni veri kaynağı eklemez. Rdatasets
psych/bfi aktarımının ilk 100 satırından A1–A5 ve C1–C5 seçilmiştir. Tam kaynak
2800 kişi/25 madde olarak belgelenmiştir; bu uygulama o tam veri değildir.

Kaynak satırları 63, 66, 90 seçili on maddede eksiktir; tüm analizler ortak 97 tam
kayıtta yürütülür. A1, C4, C5 belgelenmiş anahtarla `7-x` biçiminde çevrilir.
Bölüm 13'ün ayrı A=99 ve C=98 matrisleri birleştirilmez. Hiçbir yanıt doldurulmaz.

Sıralı ilk 100 seçim rastgele veya temsili değildir. Yerel alıntının webde
okunarak aktarımı ve otomatik uzak kaynak karşılaştırmasının yapılmamış olması
Bölüm 13 README'sinde belgelenmiştir. Bu paket kaynak hücrelerinin bağımsız
teyidi iddiasında bulunmaz. Yerel hash denetimi bunu ikame etmez. Türkçe ölçek
uyarlaması, klinik kullanım onayı veya tüm kişilik yapısının keşfi değildir.

Kaynaklar (yöntem belgeleri erişimi: 6 Eylül 2026; veri aktarımı: 5 Eylül 2026):
- https://www.personality-project.org/r/html/bfi.html
- https://raw.githubusercontent.com/vincentarelbundock/Rdatasets/master/csv/psych/bfi.csv
- https://personality-project.org/r/psych/help/fa.html
- https://personality-project.org/r/psych/help/fa.parallel.html
- https://personality-project.org/r/psych/help/KMO.html
- https://personality-project.org/r/psych/help/cortest.bartlett.html
- https://www.statsmodels.org/stable/generated/statsmodels.multivariate.factor.Factor.html
- https://www.statsmodels.org/stable/generated/statsmodels.multivariate.factor_rotation.rotate_factors.html
- Horn (1965): https://doi.org/10.1007/BF02289447
- MacCallum ve arkadaşları (1999): https://doi.org/10.1037/1082-989X.4.1.84
- https://www.ibm.com/docs/en/spss-statistics/32.0.0?topic=reference-factor

## Yeniden üretim

Kitap kökünden:

```sh
python uygulamalar/b14-faktor-analizi/analiz.py
```

Python betiği başka dizinden de kendi dosya yolu ile çalıştırılabilir.
Mevcut numpy/pandas/scipy/statsmodels/matplotlib kullanılır; sürümler JSON'a
kaydedilir. Ağ veya yeni bağımlılık kurulumu gerekmez. `puanlanmis.csv`,
`sonuclar/ozet.json`, matris CSV'leri ve kitap `assets_figures` klasöründeki
`b14-paralel-analiz.pdf`, `b14-oruntu-yapi.pdf` yeniden üretilir.

Kaynak son LF ile normalize SHA-256:
`8726fd25dbfc685be2d3d726e5511bbb31ba9c7b367b6864eb06e0d8669e6557`.
Dosyanın gerçek bayt hash'i ayrıca kaydedilir; hücre değişiklikleri normalizasyonla
saklanmaz. Kaynak dosyası işlem sonunda başlangıç baytlarıyla karşılaştırılır.

## Açık hesap tanımları

- Pearson matrisi, ortak 97 kişi; polikorik/ordinal model veya ikili eksik silme yok.
- KMO'da korelasyon ve kısmi korelasyonların köşegen dışı kareleri; madde MSA'ları.
- Bartlett klasik yaklaşık ki-kare testi; ordinal veri için dağılım varsayımları
  yaklaşık ele alınır. Anlamlılık, faktör sayısının veya geçerliğin kanıtı değildir.
- PAF: başlangıç köşegeni SMC, özdeğer yinelemesi; ortak varyans farkının Öklid normu
  `<1e-10`, en çok 2000 yineleme. Yakınsamama/pozitif özdeğer eksikliği hata verir.
  Heywood durumu ayrıca kaydedilir; bu veride 1/2/3 adayın hepsi uygun varyanslıdır.
- Quartimin eğik rotasyonu: Kaiser satır normalizasyonu **yok**, tolerans 1e-8,
  üst sınır 10000; tek başlangıçla iki algoritmanın aynı amaç değerine gelmesi
  küresel optimumun veya örneklem kararlılığının kanıtı değildir.
- Sütun sırası/işaretleri A ve C içeriklerini okunabilir kılmak için düzenlenir;
  yükler sıfıra zorlanmaz. Örüntü `L`, faktör korelasyonu `Phi`, yapı `L @ Phi`.
  Ortak matris `L @ Phi @ L.T`; özgüllük `1-diag(ortak)`.
- RMSR yalnız 45 benzersiz köşegen dışı çiftin kare ortalamasının kareköküdür.
  CFA-SRMR/RMSEA yerine geçmez. `.05` artık işaretleme eşiğidir, hipotez testi değil.
- Paralel analiz: 2000 **her sütuna ayrı permütasyon**, tohum 20261401. Sütun
  dağılımları korunur; kişi-satırı bootstrap'ından farklı olarak ilişkiler kırılır.
  Sıralı referans özdeğerlerin doğrusal %95 nicelikleri kullanılır.
  PCA köşegeni 1; SMC sürümünde her matrisin kendi SMC köşegeni kullanılır.
  İkincisi yakınsamış PAF özdeğerleri değil başlangıç azaltılmış spektrumdur.
  İlk sıradan ardışık aşma kuralıyla iki sürüm de iki boyut önerir. %95 referans
  eğrileri gözlenen özdeğer güven aralığı değildir. Normal rastgele veri veya
  ortalama referans kullanan farklı uygulamalarla birebir eşleşme beklenmez.
- 1/2/3 faktör adayları aynı 10 madde/97 kişiyle karşılaştırılır. A1/A4 çıkarma
  yalnız duyarlılık karşı örneğidir: aynı 97 kişi, 8 madde ve 28 artık çifti.
  Ana analizde madde silinmez. Farklı madde evrenindeki oranlar doğrudan kıyasla
  geçerlik iyileşmesi sayılmaz. Yük güven aralıkları, bootstrap kararlılığı,
  faktör puanları, omega, bağımsız DFA ve değişmezlik hesaplanmaz.

## Denetimler ve diğer yazılımlar

Korelasyonlar z-puan çarpımlarıyla, her SMC ayrı en küçük kareler regresyonuyla,
A1–A2 kısmi korelasyonu kalan sekiz maddeye göre artıklarla doğrulanır. PAF ortak
matrisi statsmodels ile karşılaştırılır. Döndürme özdeşlikleri, Varimax'ta ortak
matrisin korunması ve quartimin'in türevsiz algoritmayla aynı amaç değeri
kontrol edilir. Ters kodlamada KMO/Bartlett/özdeğerlerin değişmemesi ayrıca sınanır.

`analiz.R` ve `analiz.sps` önce Python'un ürettiği puanlanmış CSV'yi kitap kökünden
okur; tekrar ters kodlama yapmaz. R betiği temel R hesapları ve kuruluysa
GPArotation kullanır; paket kurmaz. R/Python RNG farkı ve faktör sırası/işareti
nedeniyle karşılaştırmalar hizalanmalıdır. SPSS betiği varsayılan normalizasyon
ve yakınsama ayarlarını kullanabilir; bunlar Python'un normalizasyonsuz rotasyonuyla
aynı değildir. SPSS çıktısındaki ayarlar kontrol edilmeden birebir eşitlik beklenmez.
SPSS betiğinde paralel analiz yoktur. **R/SPSS bu ortamda çalıştırılmadı**;
kitaptaki sayılar SPSS çıktısı veya R ile doğrulanmış sonuç olarak sunulmaz.