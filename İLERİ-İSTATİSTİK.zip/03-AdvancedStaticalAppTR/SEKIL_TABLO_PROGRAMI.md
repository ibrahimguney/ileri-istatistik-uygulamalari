# Şekil ve Tablo Programı

Bu program, revizyon paketindeki görsel eksiklerini bölüm bazında uygulanabilir üretim listesine dönüştürür. Hedef, her bölümde en az bir numaralı şekil veya tablo; omurga bölümlerde 2--3 görsel kullanmaktır.

| Bölüm | Öncelik | Önerilen öğe | Üretim biçimi | Yerleşim |
|---|---:|---|---|---|
| b01 İstatistiksel Mekanizma | 2 | Analiz seçme karar ağacı | TikZ | Kuramsal Açıklama sonrası |
| b02 Betimsel İstatistik | 1 | Histogram + kutu grafiği | Python/PDF veya TikZ | Örnek veri sonrası |
| b02 Betimsel İstatistik | 1 | Frekans tablosu | LaTeX `table` | Çözümler içinde |
| b02a Veri Hazırlama | 1 | Eksik veri deseni ısı haritası | Python/PDF | Eksik veri bölümü |
| b02a Veri Hazırlama | 2 | Aykırı değer kutu grafiği | Python/PDF | Aykırı değer bölümü |
| b03 Hipotez Testi | 2 | Tek/çift kuyruk karar bölgeleri | TikZ/pgfplots | Kuramsal Açıklama sonrası |
| b03a Güç Analizi | 1 | n--güç eğrisi | Python/PDF | Adım adım çözüm sonrası |
| b03a Güç Analizi | 1 | Etki büyüklüğü eşikleri tablosu | LaTeX `table` | Kuramsal Açıklama sonrası |
| b04 Korelasyon | 1 | Pozitif/negatif/sıfır ilişki saçılım panelleri | Python/PDF | Problem örnekleri sonrası |
| b05 Regresyon | 1 | Regresyon doğrusu ve artıklar | Python/PDF | Model açıklaması sonrası |
| b05 Regresyon | 1 | Örnek regresyon çıktı tablosu | LaTeX `table` | Raporlama İlkeleri içinde |
| b05a Lojistik Regresyon | 2 | Lojistik S-eğrisi | Python/PDF | Kuramsal bölüm sonrası |
| b05b Aracılık/Düzenleyicilik | 1 | Aracılık yol diyagramı | TikZ | Model tanıtımı sonrası |
| b05b Aracılık/Düzenleyicilik | 2 | Etkileşim eğimleri grafiği | Python/PDF | Düzenleyicilik sonrası |
| b06 Parametrik Testler | 1 | t-testi örnek çıktı tablosu | LaTeX `table` | Raporlama örneği sonrası |
| b07 ANOVA | 1 | Grup ortalamaları hata çubuklu grafik | Python/PDF | Problem çözümü sonrası |
| b07 ANOVA | 1 | ANOVA özet tablosu | LaTeX `table` | Raporlama İlkeleri içinde |
| b08 Parametrik Olmayan Testler | 1 | Mann--Whitney sıra ortalamaları tablosu | LaTeX `table` | Çözüm sonrası |
| b09 Güvenirlik | 1 | Madde-toplam korelasyonu tablosu | LaTeX `table` | Madde analizi sonrası |
| b10 Faktör Analizi | 1 | Scree plot | Python/PDF | Faktör sayısı bölümü |
| b10 Faktör Analizi | 1 | KMO/Bartlett ve yükler tablosu | LaTeX `table` | Çözüm sonrası |
| b11 DFA | Tamam | AMOS üç faktörlü diyagram | Mevcut figür | Korunacak |
| b12 SEM | Tamam | AMOS/YEM yol diyagramı | Mevcut figür | Korunacak |
| b12 SEM | 2 | Aracılık etkisi yol diyagramı | TikZ | Aracılık örneği sonrası |
| b13 ANCOVA | 1 | Düzeltilmiş ortalamalar grafiği | Python/PDF | Problem çözümü sonrası |
| b13 ANCOVA | 1 | ANCOVA özet tablosu | LaTeX `table` | Raporlama İlkeleri içinde |
| b14 SPSS Uygulamaları | 2 | Örnek SPSS çıktı tabloları | LaTeX benzetim tabloları | İlgili analiz başlıkları |

## Uygulama Notları

- Telif riski nedeniyle gerçek SPSS ekran görüntüsü yerine eğitim amaçlı yeniden oluşturulmuş LaTeX çıktı tabloları tercih edilmelidir.
- Grafikler için `assets/figures/` altında PDF çıktılar üretilebilir; kaynak üretim betikleri `assets/scripts/` altında tutulabilir.
- Tablo numaralandırması için standart `table` ortamı kullanılmalı; mevcut merkezlenmiş `tabular` blokları gerektiğinde `table` içine alınmalıdır.
- Öncelik 1 öğeleri tamamlandığında kitapta numaralı tablo eksikliği giderilir ve bölüm başına görsel hedefinin büyük kısmı karşılanır.