#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
rm -f main.aux main.bbl main.blg main.fdb_latexmk main.fls main.log main.out main.toc main.lof main.lot main.synctex.gz main.synctex