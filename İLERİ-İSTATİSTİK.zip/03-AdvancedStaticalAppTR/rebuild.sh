#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
bash clean.sh
bash build.sh "$@"