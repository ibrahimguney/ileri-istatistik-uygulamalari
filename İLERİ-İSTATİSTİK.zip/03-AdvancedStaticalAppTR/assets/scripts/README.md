# Grafik dosyalarının denetimi ve geri yüklenmesi

Kitap kökünden:

```sh
python3 assets/scripts/restore_figures.py --check
python3 assets/scripts/restore_figures.py --repair
bash build.sh --no-bibtex
```

Denetim, `main.tex` ve çağırdığı LaTeX dosyalarındaki açık `includegraphics`
yollarını izler. Eksik dosya varsa sıfırdan farklı çıkış kodu verir;
`build.sh` derlemeden önce bu denetimi çalıştırır. Editörün doğrudan LaTeX
çağrısı bu kabuk betiğini kullanmıyorsa denetim komutu ayrıca çalıştırılabilir.

`--repair`, mevcut bölüm analizlerini geçici bir çalışma kopyasında yürütür.
Yalnız eksik PDF'ler `assets_figures` dizinine aktarılır; ham kaynaklar,
mevcut analiz sonuçları, mevcut grafikler ve bölüm metinleri değiştirilmez.
Kaynak/hash veya hesap denetimi başarısız olursa PDF aktarımı yapılmaz ve
betiğin hata mesajı gösterilir. Yeni bağımlılık kurulmaz; analiz betiklerinin
NumPy, SciPy, pandas, matplotlib ve statsmodels gereksinimleri geçerlidir.
R, SPSS ve AMOS çalıştırılmaz; uzak kaynak doğrulama seçenekleri kullanılmaz.

Eski 14 bölümlü düzenin bazı grafik adları 18 bölümlü kitapta hâlâ geçerlidir.
Örneğin `b05b-etkilesim-egimleri.pdf`, Bölüm 9'da kullanılan kavramsal şekildir.
Dosya adının bölüm numarasına benzememesi tek başına yanlış eşleşme değildir.
Gerçek veri grafiklerinin yerine bu eski kavramsal şekiller kopyalanmaz;
yeni grafikler kendi bölümünün `uygulamalar/.../analiz.py` dosyasından üretilir.
Eski kavramsal şekiller eksilirse `generate_figures.py` geçici kopyada çalışır;
`assets/figures` çıktısı doğru `assets_figures` çağrı yoluna aktarılır.

6 Eylül 2026 denetiminde 31 grafik çağrısının 24 PDF'si eksikti. Bu dosyaların
üretimi 17 bölüm betiğiyle eşleştirildi. Logo ve mevcut altı PDF korundu.
Dosyalar proje yedeklerine/dışa aktarımlara grafiklerle birlikte dahil edilmelidir;
yalnız `.tex` dosyalarını aktarmak yeterli değildir.