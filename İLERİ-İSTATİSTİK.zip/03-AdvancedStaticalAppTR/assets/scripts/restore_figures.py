import argparse
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile


GENERATORS = {
    "b01": "b01-istatistiksel-mekanizma", "b02": "b02-betimsel-istatistik",
    "b03": "b03-veri-hazirlama", "b04": "b04-hipotez-testi",
    "b05": "b05-guc-analizi", "b06": "b06-korelasyon",
    "b07": "b07-regresyon", "b08": "b08-coklu-lojistik",
    "b10": "b10-parametrik-testler", "b11": "b11-varyans-analizi",
    "b12": "b12-parametrik-olmayan", "b13": "b13-guvenirlik",
    "b14": "b14-faktor-analizi", "b15": "b15-dogrulayici-faktor",
    "b16": "b16-yapisal-esitlik", "b17": "b17-kovaryans-analizi",
    "b18": "b18-spss-uygulamalar",
}
LEGACY = {
    "b02-histogram-kutu.pdf", "b02a-eksik-veri-isi-haritasi.pdf",
    "b03-t-ret-bolgeleri.pdf", "b03a-guc-egrisi.pdf",
    "b04-korelasyon-sacilim.pdf", "b05-regresyon-artiklar.pdf",
    "b05a-lojistik-s-egrisi.pdf", "b05b-etkilesim-egimleri.pdf",
    "b06-guven-araligi.pdf", "b07-anova-ortalamalar.pdf",
    "b08-sira-dagilimi.pdf", "b09-madde-toplam-grafigi.pdf",
    "b10-scree-grafigi.pdf", "b13-duzeltilmis-ortalamalar.pdf",
    "b14-spss-raporlama-akisi.pdf",
}


def graphic_references(root):
    pending, visited, references = [Path("main.tex")], set(), set()
    while pending:
        source = pending.pop()
        if source in visited:
            continue
        visited.add(source)
        text = re.sub(r"(?<!\\)%[^\n]*", "", (root / source).read_text())
        references.update(re.findall(r"\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}", text))
        for name in re.findall(r"\\(?:input|include)\{([^}]+)\}", text):
            pending.append(Path(name) if Path(name).suffix else Path(name + ".tex"))
    return sorted(references)


def missing_graphics(root):
    references = graphic_references(root)
    missing = [name for name in references if not (root / name).is_file()]
    print(f"Grafik çağrısı: {len(references)}; eksik dosya: {len(missing)}", flush=True)
    for name in missing:
        print(f"  {name}", flush=True)
    return missing


def repair(root, missing):
    jobs = {}
    for name in missing:
        graphic = Path(name)
        if graphic.parent != Path("assets_figures") or graphic.suffix != ".pdf":
            raise ValueError(f"Otomatik üretim tanımlı değil: {name}")
        if graphic.name in LEGACY:
            script = Path("assets/scripts/generate_figures.py")
            generated = Path("assets/figures") / graphic.name
        else:
            directory = GENERATORS.get(graphic.name.split("-", 1)[0])
            if directory is None:
                raise ValueError(f"Üretim betiği eşleşmedi: {name}")
            script = Path("uygulamalar") / directory / "analiz.py"
            generated = graphic
        jobs.setdefault(script, []).append((generated, graphic))
    with tempfile.TemporaryDirectory(prefix=".grafik-uretim-", dir=root) as temporary:
        staging = Path(temporary)
        shutil.copytree(root / "uygulamalar", staging / "uygulamalar",
                        ignore=shutil.ignore_patterns("__pycache__"))
        shutil.copytree(root / "assets/scripts", staging / "assets/scripts")
        (staging / "assets_figures").mkdir()
        environment = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "MPLBACKEND": "Agg"}
        for script, outputs in sorted(jobs.items()):
            print(f"Üretiliyor: {script}", flush=True)
            result = subprocess.run([sys.executable, str(script)], cwd=staging,
                                    env=environment, capture_output=True, text=True)
            if result.returncode:
                raise RuntimeError(f"{script}\n{result.stdout}\n{result.stderr}")
            if result.stderr.strip():
                print(result.stderr, file=sys.stderr)
            for generated, graphic in outputs:
                content = (staging / generated).read_bytes()
                if not content.startswith(b"%PDF-") or len(content) < 100:
                    raise ValueError(f"Geçersiz PDF: {generated}")
        for outputs in jobs.values():
            for generated, graphic in outputs:
                (root / graphic).parent.mkdir(parents=True, exist_ok=True)
                if not (root / graphic).exists():
                    shutil.copyfile(staging / generated, root / graphic)
                    print(f"Geri yüklendi: {graphic}", flush=True)


def main():
    parser = argparse.ArgumentParser(description="Kitabın grafik dosyalarını denetle ve eksikleri yeniden üret.")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--check", action="store_true", help="Yalnız denetle (varsayılan).")
    mode.add_argument("--repair", action="store_true", help="Eksikleri geçici çalışma kopyasında üret.")
    arguments = parser.parse_args()
    root = Path(os.path.relpath(Path(__file__).parent.parent.parent, Path.cwd()))
    missing = missing_graphics(root)
    if missing and arguments.repair:
        repair(root, missing)
        missing = missing_graphics(root)
    if missing:
        print("Kitap kökünden: python3 assets/scripts/restore_figures.py --repair", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())