# İleri İstatistik Uygulamaları — Revizyon Paketi (V4 → V5)

Bu belge, kitabın kaliteli yayın ölçütlerine uygunluğu için tespit edilen eksiklerin giderilmesine yönelik, doğrudan uygulanabilir malzemeleri içerir.

---

## 1. Bölüm Numarası Düzeltme Haritası

Bölüm 18 içindeki "Bölüm Bazlı SPSS Uygulama Rehberi" başlıkları ile Ek F (Cevap Anahtarı) başlıkları, kitabın eski (14 bölümlük) sürümünün numaralarını kullanıyor. Aşağıdaki eşleme uygulanmalıdır:

| Eski etiket (Böl. 18 rehberi ve Ek F) | Doğru bölüm numarası |
|---|---|
| Bölüm 1–2: Betimsel İstatistik | Bölüm 1–2 (değişmez) |
| Bölüm 3: Hipotez Testi | **Bölüm 4** |
| Bölüm 4: Korelasyon | **Bölüm 6** |
| Bölüm 5: Regresyon Analizi | **Bölüm 7** |
| Bölüm 6: Parametrik Testler | **Bölüm 10** |
| Bölüm 7: Varyans Analizi (ANOVA) | **Bölüm 11** |
| Bölüm 8: Parametrik Olmayan Testler | **Bölüm 12** |
| Bölüm 9: Ölçek Uyarlama ve Güvenirlik | **Bölüm 13** |
| Bölüm 10: Faktör Analizi | **Bölüm 14** |
| Bölüm 11: Doğrulayıcı Faktör Analizi | **Bölüm 15** |
| Bölüm 12: Yapısal Eşitlik Modellemesi | **Bölüm 16** |
| Bölüm 13: Kovaryans Analizi | **Bölüm 17** |
| Bölüm 14: SPSS Uygulamaları | **Bölüm 18** |

LaTeX önerisi: bu başlıkları elle yazmak yerine `\ref{}` / `\autoref{}` ile bölüm etiketlerine bağlayın; böylece gelecekte bölüm eklendiğinde numaralar kendiliğinden güncellenir.

---

## 2. Eksik Kaynakçalar (yapıştırmaya hazır, APA 7)

### Bölüm 3 — Veri Hazırlama ve Analize Hazırlık
1. Enders, C. K. (2010). *Applied Missing Data Analysis*. Guilford Press.
2. Little, R. J. A., & Rubin, D. B. (2019). *Statistical Analysis with Missing Data* (3rd ed.). Wiley.
3. Osborne, J. W. (2013). *Best Practices in Data Cleaning*. Sage.
4. Tabachnick, B. G., & Fidell, L. S. (2019). *Using Multivariate Statistics* (7th ed.). Pearson.
5. Hair, J. F., Black, W. C., Babin, B. J., & Anderson, R. E. (2019). *Multivariate Data Analysis* (8th ed.). Cengage.

### Bölüm 5 — Güç Analizi ve Örneklem Büyüklüğü Planlama
1. Cohen, J. (1988). *Statistical Power Analysis for the Behavioral Sciences* (2nd ed.). Lawrence Erlbaum.
2. Cohen, J. (1992). A power primer. *Psychological Bulletin, 112*(1), 155–159.
3. Faul, F., Erdfelder, E., Lang, A.-G., & Buchner, A. (2007). G*Power 3: A flexible statistical power analysis program for the social, behavioral, and biomedical sciences. *Behavior Research Methods, 39*(2), 175–191.
4. Faul, F., Erdfelder, E., Buchner, A., & Lang, A.-G. (2009). Statistical power analyses using G*Power 3.1: Tests for correlation and regression analyses. *Behavior Research Methods, 41*(4), 1149–1160.
5. Murphy, K. R., Myors, B., & Wolach, A. (2014). *Statistical Power Analysis* (4th ed.). Routledge.
6. Maxwell, S. E., & Delaney, H. D. (2004). *Designing Experiments and Analyzing Data* (2nd ed.). Lawrence Erlbaum.

### Bölüm 8 — Çoklu ve Lojistik Regresyon
1. Cohen, J., Cohen, P., West, S. G., & Aiken, L. S. (2003). *Applied Multiple Regression/Correlation Analysis for the Behavioral Sciences* (3rd ed.). Lawrence Erlbaum.
2. Hosmer, D. W., Lemeshow, S., & Sturdivant, R. X. (2013). *Applied Logistic Regression* (3rd ed.). Wiley.
3. Menard, S. (2002). *Applied Logistic Regression Analysis* (2nd ed.). Sage.
4. Kutner, M. H., Nachtsheim, C. J., Neter, J., & Li, W. (2005). *Applied Linear Statistical Models* (5th ed.). McGraw-Hill.
5. Field, A. (2018). *Discovering Statistics Using IBM SPSS Statistics* (5th ed.). Sage.

### Bölüm 9 — Aracılık ve Düzenleyicilik Analizleri
1. Baron, R. M., & Kenny, D. A. (1986). The moderator–mediator variable distinction in social psychological research: Conceptual, strategic, and statistical considerations. *Journal of Personality and Social Psychology, 51*(6), 1173–1182.
2. Hayes, A. F. (2022). *Introduction to Mediation, Moderation, and Conditional Process Analysis* (3rd ed.). Guilford Press.
3. Preacher, K. J., & Hayes, A. F. (2008). Asymptotic and resampling strategies for assessing and comparing indirect effects in multiple mediator models. *Behavior Research Methods, 40*(3), 879–891.
4. MacKinnon, D. P. (2008). *Introduction to Statistical Mediation Analysis*. Lawrence Erlbaum.
5. Aiken, L. S., & West, S. G. (1991). *Multiple Regression: Testing and Interpreting Interactions*. Sage.

### Bölüm 16 — Yapısal Eşitlik Modeli
1. Kline, R. B. (2016). *Principles and Practice of Structural Equation Modeling* (4th ed.). Guilford Press.
2. Byrne, B. M. (2016). *Structural Equation Modeling with AMOS* (3rd ed.). Routledge.
3. Hu, L., & Bentler, P. M. (1999). Cutoff criteria for fit indexes in covariance structure analysis: Conventional criteria versus new alternatives. *Structural Equation Modeling, 6*(1), 1–55.
4. Schumacker, R. E., & Lomax, R. G. (2016). *A Beginner's Guide to Structural Equation Modeling* (4th ed.). Routledge.
5. Bollen, K. A. (1989). *Structural Equations with Latent Variables*. Wiley.

> Not: Baskıdan önce her kaynağın sayfa/DOI bilgisi orijinalinden doğrulanmalıdır.

---

## 3. Metin İçi Atıf Stratejisi

Mevcut durumda gövde metinde hiç atıf yok. Öneri: her bölümde en az şu üç noktaya yazar–yıl atıfı eklenmeli:

1. **Kuramsal Açıklama** bölümünün ilk paragrafı — yöntemin standart kaynağına atıf.
   Örnek (Böl. 16): "...model uyumu değerlendirilirken CFI ≥ .95 ve RMSEA ≤ .06 eşikleri yaygın kabul görür (Hu & Bentler, 1999; Kline, 2016)."
2. **Eşik/kesim değerleri** verilen her yer (alfa ≥ .70, KMO ≥ .60, VIF < 10 vb.) — bu değerler kaynağa bağlanmadan verilmemeli.
   Örnek (Böl. 13): "İç tutarlılık için .70 düzeyi asgari kabul edilir (Nunnally & Bernstein, 1994)."
3. **Sık Yapılan Hatalar / Raporlama Dili** bölümlerinde en az bir metodolojik kaynağa atıf.

LaTeX'te `natbib` veya `biblatex` (apa stili) kullanılması, hem tutarlılığı sağlar hem kaynakça–metin uyumunu otomatik denetler (atıfsız kaynak `biber` uyarısı verir).

---

## 4. Eksik Alıştırmalar ve Cevap Anahtarları

Bölüm 3, 5, 8 ve 9'da "Bölüm Sonu Alıştırmaları" bölümü yok; buna bağlı olarak Ek F'de bu bölümlerin cevap anahtarı da yok. Kitabın diğer bölümleriyle aynı format (Kolay K1–K5, Orta O1–O5, İleri İ1–İ5) izlenerek dört bölüm için 15'er soruluk set yazılmalı. Ek F'ye eklenecek dört yeni blokla anahtar 18 bölümü de kapsar hale gelir.

---

## 5. Şekil ve Tablo Programı (asgari)

252 sayfada yalnızca 2 numaralı şekil var, numaralı tablo yok. Asgari hedef: bölüm başına 1–3 görsel.

| Bölüm | Önerilen görseller |
|---|---|
| 1–2 | Histogram, kutu grafiği, kök-yaprak örneği; frekans tablosu |
| 3 | Eksik veri deseni ısı haritası; aykırı değer kutu grafiği |
| 4 | Ret bölgesi gösterimli t dağılımı grafiği; Tip I/II hata tablosu |
| 5 | Güç eğrisi (n–güç ilişkisi); etki büyüklüğü eşikleri tablosu |
| 6 | Saçılım grafikleri (r = .2/.5/.8 karşılaştırması) |
| 7–8 | Regresyon doğrusu + artık grafiği; lojistik S eğrisi |
| 9 | Aracılık yol diyagramı (X→M→Y); etkileşim (basit eğimler) grafiği |
| 10–12 | Örnek SPSS çıktı tabloları (t-testi, ANOVA, Mann–Whitney) |
| 13–16 | Madde-toplam tablosu; yamaç-birikinti (scree) grafiği; DFA/SEM yol diyagramları |
| 17–18 | Düzeltilmiş ortalamalar grafiği; SPSS menü ekran görüntüleri |

Grafikler TikZ/pgfplots ile ya da R/Python'dan PDF olarak üretilebilir; SPSS ekran görüntüleri için IBM'in eğitim amaçlı kullanım koşulları gözetilmelidir.

---

## 6. Künye ve Ön/Arka Sayfalar

- Kapak ve iç kapaktan **"Springer Nature" ibaresi kaldırılmalı** (şablon kalıntısı; gerçek yayın sözleşmesi yoksa yanıltıcı yayınevi beyanı sayılır).
- Eklenecekler: iç kapak arkasına telif/künye sayfası (yayınevi, ISBN, sertifika no, baskı yeri/yılı, © ibaresi), "Yazar Hakkında" sayfası, varsa teşekkür.
- Arka bölüme **Dizin (Index)** eklenmeli: LaTeX'te `\usepackage{imakeidx}` + metin içinde `\index{}` etiketleri + `\printindex`. Asgari 150–200 terimlik bir dizin listesi ayrıca hazırlanabilir.

---

## 7. Dizgi Temizliği

- İçindekiler'de bitişik yazımlar ("18.10Bölüm 5..."): `tocloft` ile numara genişliği (`\cftsecnumwidth`) artırılmalı.
- Alt bölüm numarası taşmaları (ör. "15.10.6Adım 6") için aynı düzeltme alt düzeylerde de uygulanmalı.
- "Prof.Dr." → "Prof. Dr." (boşluk).
- Bölüm 16 başlığının İçindekiler'de satır kaymasıyla "Örneği" olarak bölünmesi kontrol edilmeli.

---

## Uygulama Sırası Önerisi

1. Numaralandırma düzeltmeleri (Böl. 18 + Ek F) — hızlı, mekanik.
2. Eksik kaynakçaların eklenmesi (bu belgedeki listeler).
3. Metin içi atıfların yerleştirilmesi (bölüm başına ~5–10 atıf).
4. Bölüm 3, 5, 8, 9 için alıştırma + cevap anahtarı yazımı.
5. Şekil/tablo üretimi ve yerleşimi.
6. Künye, dizin, dizgi temizliği.
7. Dış okuma (hakem) ve dil redaksiyonu → V5.
