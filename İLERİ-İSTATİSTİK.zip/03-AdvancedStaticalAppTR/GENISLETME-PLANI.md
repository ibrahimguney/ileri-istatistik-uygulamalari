# Kitap İleri İstatistik Genişletme Planı

## Amaç
Bu kopya proje, mevcut `kitap-ileri-istatistik` içeriğini daha kapsamlı bir ders kitabına dönüştürmek için oluşturulmuştur. Amaç; lisansüstü derslerde, tez çalışmalarında ve uygulamalı araştırmalarda kullanılabilecek daha ayrıntılı, örnekli ve rehber niteliğinde bir içerik yapısı kurmaktır.

## Yeni Proje Klasörü
- `prism-organizasyon/kitap-ileri-istatistik-genisletilmis`

## Çalışma İlkesi
Her bölüm aşağıdaki alt yapıya göre yeniden düzenlenecektir:
1. Giriş ve amaç
2. Temel kavramlar
3. Kuramsal açıklama
4. Formüller ve yorumlar
5. Örnek veri / örnek problem
6. Adım adım çözüm
7. SPSS/R/Python notları
8. Sık yapılan hatalar
9. Bölüm sonu özet
10. Alıştırmalar ve kaynakça

## Bölüm Önceliklendirme
Önce temel yöntem bölümleri genişletilecek, ardından çok değişkenli yöntemler ve yazılım uygulamaları derinleştirilecektir.

### 1. Aşama: Temel İstatistiksel Omurga
- [x] `b01-istatistiksel-mekanizma.tex`
- [x] `b02-betimsel-istatistik.tex`
- [ ] `b03-hipotez-testi.tex`
- [x] `b04-korelasyon.tex`
- [x] `b05-regresyon.tex`
- [x] `b06-parametrik-testler.tex`
- [x] `b07-varyans-analizi.tex`

### 2. Aşama: Orta-İleri Uygulama Bölümleri
- [x] `b08-parametrik-olmayan-testler.tex`
- [x] `b09-olcek-uyarlama-guvenirlik.tex`
- [x] `b13-Kovaryans-analizi.tex`
- [x] `b14-spss-uygulamaları.tex`

### 3. Aşama: İleri Çok Değişkenli Yapı
- [x] `b10-faktor-analizi.tex`
- [x] `b11-doğrulayıcı-faktor-analizi.tex`
- [x] `b12-yapısal-esitlik-modeli.tex`

## Bölüm Bazlı Genişletme Hedefleri

### b01 - İstatistiksel Mekanizma
Hedef; araştırma sorusu, değişken türü, veri yapısı ve uygun analiz seçimi arasında sistematik bağ kuran bir giriş bölümü oluşturmaktır. Karar verme süreçleri, veri görselleştirme mantığı, değişken sınıflamaları ve araştırma tasarımıyla yöntem seçimi arasındaki ilişki daha ayrıntılı anlatılmalıdır. Bölüme karar ağacı, örnek araştırma senaryoları ve analiz seçme rehberi eklenmelidir.

### b02 - Betimsel İstatistik
Merkezi eğilim, yayılım, dağılım yapısı, çarpıklık-basıklık ve görsel özetleme konuları daha güçlü örneklerle genişletilmelidir. Her ölçünün ne zaman tercih edileceği ve yanlış yorum riskleri açıklanmalıdır. Tablolar, kutu grafikleri, histogramlar ve raporlama örnekleri artırılmalıdır.

### b03 - Hipotez Testi
Sıfır ve alternatif hipotez, hata türleri, anlamlılık, p-değeri, güven aralığı ve etki büyüklüğü ilişkisi daha kapsamlı ele alınmalıdır. Bu bölümde karar mantığı ile raporlama dili birlikte öğretilmelidir. Tez ve makale diline uygun yorum örnekleri eklenmelidir.

### b04 - Korelasyon
Pearson, Spearman ve gerekirse diğer ilişki katsayıları karşılaştırmalı verilebilir. İlişki gücü, yönü, doğrusal olmayan yapı, aykırı değer etkisi ve korelasyonun nedensellik anlamına gelmediği açık vurgulanmalıdır. Korelasyon matrisi yorumlama ve araştırma sorusuna uygun katsayı seçimi örneklendirilmelidir.

### b05 - Regresyon
Basit doğrusal regresyon; model mantığı, katsayıların yorumu, hata terimi, tahmin, uygunluk ve varsayımlar bakımından genişletilmelidir. Regresyon çıktılarının tablo düzeyinde okunuşu ve sonuçların akademik metne dönüştürülmesi gösterilmelidir. Bölüme örnek veri setiyle adım adım çözüm eklenmelidir.

### b06 - Parametrik Testler
Bağımsız örneklem t testi, bağımlı örneklem t testi ve tek örneklem t testi için ayrı mini alt şablon kurulmalıdır. Normallik, varyans homojenliği ve örneklem yapısı ayrıntılandırılmalıdır. Etki büyüklüğü ve bulgu raporlama biçimleri mutlaka eklenmelidir.

### b07 - Varyans Analizi
Tek yönlü ve mümkünse faktöriyel ANOVA mantığı daha sistematik verilmelidir. Post-hoc testler, etki büyüklüğü, grafik destekli yorum ve homojenlik varsayımları açıklaştırılmalıdır. Uygulama odaklı örnek senaryolarla bölüm güçlendirilmelidir.

### b08 - Parametrik Olmayan Testler
Bu bölüm zaten görece kapsamlıdır; ancak test seçim rehberi daha görünür hale getirilmelidir. Mann-Whitney U, Wilcoxon, Kruskal-Wallis, Friedman ve Ki-kare testleri için hangi veri yapısında hangi testin seçileceği tabloyla özetlenmelidir. Parametrik ve parametrik olmayan yaklaşımlar karşılaştırılmalıdır.

### b09 - Ölçek Güvenirliği
Güvenirlik kavramı, Cronbach alfa, madde-toplam korelasyonu, madde analizi ve ölçek geliştirme/uyarlama bağlamı daha detaylı işlenmelidir. Bu bölümde yalnızca SPSS adımları değil, karar ölçütlerinin neden önemli olduğu da açıklanmalıdır. Örnek ölçek değerlendirme senaryosu eklenmelidir.

### b10 - Faktör Analizi
Açımlayıcı faktör analizinin mantığı, ön koşulları, KMO-Bartlett testleri, faktör yükleri, döndürme türleri ve madde çıkarma kriterleri detaylandırılmalıdır. Araştırma raporunda AFA sonuçlarının nasıl sunulacağı örneklenmelidir. Madde seçim kararları ve faktör adlandırma mantığı ayrıca açıklanmalıdır.

### b11 - Doğrulayıcı Faktör Analizi
DFA bölümünde model kurma mantığı, uyum indeksleri, modifikasyonların dikkatli kullanımı ve doğrulama yaklaşımı daha açık anlatılmalıdır. Özellikle AFA-DFA ayrımı, model doğrulama mantığı ve sonuçların yazımı güçlendirilmelidir. SPSS/AMOS ekran mantığına ek olarak kuramsal karar noktaları belirtilmelidir.

### b12 - Yapısal Eşitlik Modeli
Bu bölüm geniş kitabın omurga bölümlerinden biri olmalıdır. Ölçüm modeli, yapısal model, doğrudan/dolaylı etkiler, aracılık, uyum indeksleri ve model iyileştirme mantığı daha kapsamlı biçimde ele alınmalıdır. Uygulama örnekleri ve tez düzeyinde yorum şablonları eklenmelidir.

### b13 - Kovaryans Analizi
ANCOVA için kovaryat mantığı, düzeltilmiş ortalamalar, eğimlerin homojenliği ve yorumlama aşamaları daha net yapılandırılmalıdır. ANOVA ile ANCOVA arasındaki farklar tablo halinde verilebilir. Uygulama çıktılarının yorumlanması ayrıntılandırılmalıdır.

### b14 - SPSS Uygulamaları
Bu bölüm, kitabın uygulama kılavuzu gibi yeniden yapılandırılabilir. Bölüm bazlı ekran yürüyüşleri, çıktı okuma rehberleri ve kısa problem senaryoları eklenmelidir. Gerekirse bu bölüm kitap boyunca geçen analizlerin toplu uygulama rehberi olarak konumlandırılmalıdır.

## Uygulama Biçimi
Her bölüm için aşağıdaki sırayla çalışılması önerilir:
1. Mevcut metni koru
2. Giriş ve amaç kısmını yaz
3. Temel kavramlar bölümünü düzenle
4. Kuramsal açıklama ve formülleri genişlet
5. Örnek veri / örnek problem ekle
6. Adım adım çözüm yaz
7. SPSS/R/Python notlarını ekle
8. Sık yapılan hataları belirt
9. Bölüm özeti ve alıştırmaları ekle
10. Kaynakça ile bölümü tamamla
11. Derleme kontrolü yap

## Önerilen İlk Pilot Bölümler
Şablonu oturtmak için önce şu iki bölüm genişletilmelidir:
- [ ] `b03-hipotez-testi.tex`
- [x] `b05-regresyon.tex`

`b05` tamamlanmış, genişletme şablonu ise artık birden çok bölüm üzerinde uygulanmış durumdadır. Bu aşamada kitap genelinde kullanılan uzunluk, pedagojik akış ve yazım standardı büyük ölçüde netleşmiştir.

## Tamamlanma Özeti
- Toplam ana bölüm sayısı: `14`
- Genişletmesi tamamlanan bölüm sayısı: `13`
- Kalan ana bölüm: `b03-hipotez-testi.tex`
- Son derleme durumu: `main.pdf` başarıyla üretiliyor

## Teknik Not
Her büyük düzenlemeden sonra aşağıdaki komutla derleme kontrolü yapılmalıdır:
- `latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex`

## Güncel Durum
- Tamamlanan genişletilmiş bölümler: `b01`, `b02`, `b04`, `b05`, `b06`, `b07`, `b08`, `b09`, `b10`, `b11`, `b12`, `b13`, `b14`
- Henüz genişletme işareti konulmayan ana bölüm: `b03-hipotez-testi.tex`
- Derleme kontrolü yapılmış ve belge `main.pdf` olarak başarıyla üretilmiştir.